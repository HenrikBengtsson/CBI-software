clpAPI
======

R Interface to C API of COIN-OR Clp, depends on COIN-OR Clp Version >= 1.12.0
